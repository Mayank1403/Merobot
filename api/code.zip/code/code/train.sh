#train
python Train/boxGCNVAE.py
python Train/maskVAE.py

#label-maps-processing
python C-SPADE/datasets/convert.py

#train c-spade
bash Train/c-spade_train.sh

