import os, sys
sys.path.insert(0, os.getcwd())
sys.path.insert(0,'../SPADE')
