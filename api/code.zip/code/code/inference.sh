#infer
python Inference/boxGCNVAE.py
python Inference/maskVAE.py

#label-maps-processing
python C-SPADE/datasets/convert.py

bash Inference/c-spade_test.sh
