To run the following repository, please install the following dependencies:

pip install numpy
pip install matplotlib
pip install opencv-python
pip install pickle5
pip install tensorflow-gpu==1.3.0

pip install torch>=1.0.0
pip install torchvision
pip install dominate>=2.3.1
pip install dill
pip install scikit-image

After installing the following dependencies run the bash scripts given in the folder.

To preprocess and get the data run.

sh preprocess.sh

To train the model run the train script.

sh train.sh

To get the generations from inference files, get the pretrained models in the directory and run inference script.

box-gcnvae model drive link:

https://drive.google.com/file/d/1BBNY78L8rd5FUfD2sKpAt8sZZokxtH4w/view?usp=sharing, https://drive.google.com/file/d/1Vi3bEHn1zeYVPOBGqGXXxEzDFuEszN1g/view?usp=sharing, https://drive.google.com/file/d/1nVRr1gNCqPNYVE1sYmvl8p2zoJ0X4Bki/view?usp=sharing

mask-vae model drive link:

https://drive.google.com/file/d/1DE3WxLelrUpKB1stQP1P2D8hsMcTzq8S/view?usp=sharing, https://drive.google.com/file/d/1ELUtvKC5yp6Jy-R-jZvqTOsw2e6WsKnr/view?usp=sharing, https://drive.google.com/file/d/1IlpgZQb32N11K-ooI_vayftGD4P57ml0/view?usp=sharing

C-SPADE model drive link:

https://drive.google.com/drive/folders/1mL6nqHorIMYiNJ0z4SGJj7O3bw7zIVB-?usp=sharing

sh inference.sh
